# Projet Python Semestre 2

Projet de création du jeu de cartes "Réussite des Alliances" en language Python pour le deuxième semestre.

## Membres du groupe

- Mohammed Amine ROSTANE
- Gaillor Jowardo JINORO

## Compilation

- main.py -> version terminal.
- GUI/main.py -> version graphique.