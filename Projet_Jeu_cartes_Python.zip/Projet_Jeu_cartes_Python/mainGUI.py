from affichage_GUI import partie, get_font, main_menu
from cartes import Carte
from game import Game
from button import Button
import pygame, sys
import os

pygame.init()
pygame.mixer.init()






def main():
    main_menu()


if __name__ == '__main__':
    main()
